gdjs.Cena2Code = {};
gdjs.Cena2Code.GDbala1Objects1_1final = [];

gdjs.Cena2Code.GDbalinhaObjects1_1final = [];

gdjs.Cena2Code.GDcanhao3Objects1_1final = [];

gdjs.Cena2Code.GDdangerObjects1_1final = [];

gdjs.Cena2Code.GDinim1Objects1_1final = [];

gdjs.Cena2Code.GDinim2Objects1_1final = [];

gdjs.Cena2Code.GDinim3Objects1_1final = [];

gdjs.Cena2Code.GDmissil3Objects1_1final = [];

gdjs.Cena2Code.forEachIndex2 = 0;

gdjs.Cena2Code.forEachObjects2 = [];

gdjs.Cena2Code.forEachTemporary2 = null;

gdjs.Cena2Code.forEachTotalCount2 = 0;

gdjs.Cena2Code.GDterrenoObjects1= [];
gdjs.Cena2Code.GDterrenoObjects2= [];
gdjs.Cena2Code.GDtankObjects1= [];
gdjs.Cena2Code.GDtankObjects2= [];
gdjs.Cena2Code.GDcanhao3Objects1= [];
gdjs.Cena2Code.GDcanhao3Objects2= [];
gdjs.Cena2Code.GDmissil2Objects1= [];
gdjs.Cena2Code.GDmissil2Objects2= [];
gdjs.Cena2Code.GDbala1Objects1= [];
gdjs.Cena2Code.GDbala1Objects2= [];
gdjs.Cena2Code.GDbalinhaObjects1= [];
gdjs.Cena2Code.GDbalinhaObjects2= [];
gdjs.Cena2Code.GDchamaObjects1= [];
gdjs.Cena2Code.GDchamaObjects2= [];
gdjs.Cena2Code.GDexplosaoObjects1= [];
gdjs.Cena2Code.GDexplosaoObjects2= [];
gdjs.Cena2Code.GDsangueObjects1= [];
gdjs.Cena2Code.GDsangueObjects2= [];
gdjs.Cena2Code.GDinim1Objects1= [];
gdjs.Cena2Code.GDinim1Objects2= [];
gdjs.Cena2Code.GDinim2Objects1= [];
gdjs.Cena2Code.GDinim2Objects2= [];
gdjs.Cena2Code.GDdangerObjects1= [];
gdjs.Cena2Code.GDdangerObjects2= [];
gdjs.Cena2Code.GDlevelObjects1= [];
gdjs.Cena2Code.GDlevelObjects2= [];
gdjs.Cena2Code.GDlevel_95nObjects1= [];
gdjs.Cena2Code.GDlevel_95nObjects2= [];
gdjs.Cena2Code.GDscoreObjects1= [];
gdjs.Cena2Code.GDscoreObjects2= [];
gdjs.Cena2Code.GDn_95inimigosObjects1= [];
gdjs.Cena2Code.GDn_95inimigosObjects2= [];
gdjs.Cena2Code.GDtempoObjects1= [];
gdjs.Cena2Code.GDtempoObjects2= [];
gdjs.Cena2Code.GDinim11Objects1= [];
gdjs.Cena2Code.GDinim11Objects2= [];
gdjs.Cena2Code.GDmedalObjects1= [];
gdjs.Cena2Code.GDmedalObjects2= [];
gdjs.Cena2Code.GDampulhetaObjects1= [];
gdjs.Cena2Code.GDampulhetaObjects2= [];
gdjs.Cena2Code.GDteclasObjects1= [];
gdjs.Cena2Code.GDteclasObjects2= [];
gdjs.Cena2Code.GDpointerObjects1= [];
gdjs.Cena2Code.GDpointerObjects2= [];
gdjs.Cena2Code.GDleftObjects1= [];
gdjs.Cena2Code.GDleftObjects2= [];
gdjs.Cena2Code.GDrightObjects1= [];
gdjs.Cena2Code.GDrightObjects2= [];
gdjs.Cena2Code.GDinfo1Objects1= [];
gdjs.Cena2Code.GDinfo1Objects2= [];
gdjs.Cena2Code.GDinfo2Objects1= [];
gdjs.Cena2Code.GDinfo2Objects2= [];
gdjs.Cena2Code.GDinfo3Objects1= [];
gdjs.Cena2Code.GDinfo3Objects2= [];
gdjs.Cena2Code.GDinfo4Objects1= [];
gdjs.Cena2Code.GDinfo4Objects2= [];
gdjs.Cena2Code.GDinim3Objects1= [];
gdjs.Cena2Code.GDinim3Objects2= [];
gdjs.Cena2Code.GDmissil3Objects1= [];
gdjs.Cena2Code.GDmissil3Objects2= [];
gdjs.Cena2Code.GDinim4Objects1= [];
gdjs.Cena2Code.GDinim4Objects2= [];
gdjs.Cena2Code.GDn_95inimigos2Objects1= [];
gdjs.Cena2Code.GDn_95inimigos2Objects2= [];
gdjs.Cena2Code.GDinim41Objects1= [];
gdjs.Cena2Code.GDinim41Objects2= [];

gdjs.Cena2Code.conditionTrue_0 = {val:false};
gdjs.Cena2Code.condition0IsTrue_0 = {val:false};
gdjs.Cena2Code.condition1IsTrue_0 = {val:false};
gdjs.Cena2Code.condition2IsTrue_0 = {val:false};
gdjs.Cena2Code.condition3IsTrue_0 = {val:false};
gdjs.Cena2Code.condition4IsTrue_0 = {val:false};
gdjs.Cena2Code.condition5IsTrue_0 = {val:false};
gdjs.Cena2Code.condition6IsTrue_0 = {val:false};
gdjs.Cena2Code.conditionTrue_1 = {val:false};
gdjs.Cena2Code.condition0IsTrue_1 = {val:false};
gdjs.Cena2Code.condition1IsTrue_1 = {val:false};
gdjs.Cena2Code.condition2IsTrue_1 = {val:false};
gdjs.Cena2Code.condition3IsTrue_1 = {val:false};
gdjs.Cena2Code.condition4IsTrue_1 = {val:false};
gdjs.Cena2Code.condition5IsTrue_1 = {val:false};
gdjs.Cena2Code.condition6IsTrue_1 = {val:false};


gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil2Objects1Objects = Hashtable.newFrom({"missil2": gdjs.Cena2Code.GDmissil2Objects1});gdjs.Cena2Code.eventsList0x760454 = function(runtimeScene) {

{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "disparo");
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
gdjs.Cena2Code.GDcanhao3Objects1.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDmissil2Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil2Objects1Objects, (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointX("mira3")), (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointY("mira3")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "som\\rocket.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Cena2Code.GDmissil2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDmissil2Objects1[i].setZOrder(80);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDmissil2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDmissil2Objects1[i].setAngle((( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDmissil2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDmissil2Objects1[i].addPolarForce((gdjs.Cena2Code.GDmissil2Objects1[i].getAngle()), 750, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "disparo");
}}

}


}; //End of gdjs.Cena2Code.eventsList0x760454
gdjs.Cena2Code.eventsList0x760274 = function(runtimeScene) {

{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
{gdjs.Cena2Code.conditionTrue_1 = gdjs.Cena2Code.condition0IsTrue_0;
gdjs.Cena2Code.condition0IsTrue_1.val = false;
{
gdjs.Cena2Code.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
}gdjs.Cena2Code.conditionTrue_1.val = true && gdjs.Cena2Code.condition0IsTrue_1.val;
}
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Cena2Code.eventsList0x760454(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.Cena2Code.eventsList0x760274
gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbalinhaObjects1Objects = Hashtable.newFrom({"balinha": gdjs.Cena2Code.GDbalinhaObjects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDchamaObjects1Objects = Hashtable.newFrom({"chama": gdjs.Cena2Code.GDchamaObjects1});gdjs.Cena2Code.eventsList0x760e1c = function(runtimeScene) {

{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.1, "disparo1");
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
gdjs.Cena2Code.GDcanhao3Objects1.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDbalinhaObjects1.length = 0;

gdjs.Cena2Code.GDchamaObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbalinhaObjects1Objects, (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointX("mira31")), (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointY("mira31")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDchamaObjects1Objects, (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointX("mira31")), (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointY("mira31")), "");
}{for(var i = 0, len = gdjs.Cena2Code.GDbalinhaObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDbalinhaObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDchamaObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDchamaObjects1[i].setZOrder(100);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "som\\tiro1.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Cena2Code.GDbalinhaObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDbalinhaObjects1[i].setAngle((( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDchamaObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDchamaObjects1[i].setAngle((( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDbalinhaObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDbalinhaObjects1[i].addPolarForce((gdjs.Cena2Code.GDbalinhaObjects1[i].getAngle()), 1000, 1);
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "disparo1");
}}

}


}; //End of gdjs.Cena2Code.eventsList0x760e1c
gdjs.Cena2Code.eventsList0x760c14 = function(runtimeScene) {

{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
{gdjs.Cena2Code.conditionTrue_1 = gdjs.Cena2Code.condition0IsTrue_0;
gdjs.Cena2Code.condition0IsTrue_1.val = false;
{
gdjs.Cena2Code.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
}gdjs.Cena2Code.conditionTrue_1.val = true && gdjs.Cena2Code.condition0IsTrue_1.val;
}
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Cena2Code.eventsList0x760e1c(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.Cena2Code.eventsList0x760c14
gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim2Objects1Objects = Hashtable.newFrom({"inim2": gdjs.Cena2Code.GDinim2Objects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim3Objects1Objects = Hashtable.newFrom({"inim3": gdjs.Cena2Code.GDinim3Objects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim4Objects1Objects = Hashtable.newFrom({"inim4": gdjs.Cena2Code.GDinim4Objects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim4Objects1Objects = Hashtable.newFrom({"inim4": gdjs.Cena2Code.GDinim4Objects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim4Objects1Objects = Hashtable.newFrom({"inim4": gdjs.Cena2Code.GDinim4Objects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil2Objects1Objects = Hashtable.newFrom({"missil2": gdjs.Cena2Code.GDmissil2Objects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim1Objects1Objects = Hashtable.newFrom({"inim1": gdjs.Cena2Code.GDinim1Objects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects = Hashtable.newFrom({"explosao": gdjs.Cena2Code.GDexplosaoObjects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil2Objects1Objects = Hashtable.newFrom({"missil2": gdjs.Cena2Code.GDmissil2Objects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim4Objects1Objects = Hashtable.newFrom({"inim4": gdjs.Cena2Code.GDinim4Objects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects = Hashtable.newFrom({"explosao": gdjs.Cena2Code.GDexplosaoObjects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbalinhaObjects2Objects = Hashtable.newFrom({"balinha": gdjs.Cena2Code.GDbalinhaObjects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim2Objects2Objects = Hashtable.newFrom({"inim2": gdjs.Cena2Code.GDinim2Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbalinhaObjects2Objects = Hashtable.newFrom({"balinha": gdjs.Cena2Code.GDbalinhaObjects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim3Objects2Objects = Hashtable.newFrom({"inim3": gdjs.Cena2Code.GDinim3Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDsangueObjects1Objects = Hashtable.newFrom({"sangue": gdjs.Cena2Code.GDsangueObjects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects = Hashtable.newFrom({"explosao": gdjs.Cena2Code.GDexplosaoObjects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbalinhaObjects1Objects = Hashtable.newFrom({"balinha": gdjs.Cena2Code.GDbalinhaObjects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil3Objects1Objects = Hashtable.newFrom({"missil3": gdjs.Cena2Code.GDmissil3Objects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects = Hashtable.newFrom({"explosao": gdjs.Cena2Code.GDexplosaoObjects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbala1Objects2Objects = Hashtable.newFrom({"bala1": gdjs.Cena2Code.GDbala1Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDchamaObjects2Objects = Hashtable.newFrom({"chama": gdjs.Cena2Code.GDchamaObjects2});gdjs.Cena2Code.eventsList0x71fa4c = function(runtimeScene) {

}; //End of gdjs.Cena2Code.eventsList0x71fa4c
gdjs.Cena2Code.eventsList0x764ef4 = function(runtimeScene) {

{

gdjs.Cena2Code.GDinim1Objects1.createFrom(runtimeScene.getObjects("inim1"));

for(gdjs.Cena2Code.forEachIndex2 = 0;gdjs.Cena2Code.forEachIndex2 < gdjs.Cena2Code.GDinim1Objects1.length;++gdjs.Cena2Code.forEachIndex2) {
gdjs.Cena2Code.GDbala1Objects2.length = 0;

gdjs.Cena2Code.GDchamaObjects2.length = 0;

gdjs.Cena2Code.GDinim1Objects2.length = 0;


gdjs.Cena2Code.forEachTemporary2 = gdjs.Cena2Code.GDinim1Objects1[gdjs.Cena2Code.forEachIndex2];
gdjs.Cena2Code.GDinim1Objects2.push(gdjs.Cena2Code.forEachTemporary2);
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbala1Objects2Objects, (( gdjs.Cena2Code.GDinim1Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim1Objects2[0].getPointX("mira_inim1")), (( gdjs.Cena2Code.GDinim1Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim1Objects2[0].getPointY("mira_inim1")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDchamaObjects2Objects, (( gdjs.Cena2Code.GDinim1Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim1Objects2[0].getPointX("mira_inim1")), (( gdjs.Cena2Code.GDinim1Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim1Objects2[0].getPointY("mira_inim1")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "som\\canhao_inim.wav", false, 50, 1);
}{for(var i = 0, len = gdjs.Cena2Code.GDbala1Objects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDbala1Objects2[i].setZOrder(90);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDchamaObjects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDchamaObjects2[i].setZOrder(90);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDbala1Objects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDbala1Objects2[i].setAngle((( gdjs.Cena2Code.GDinim1Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim1Objects2[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDchamaObjects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDchamaObjects2[i].setAngle((( gdjs.Cena2Code.GDinim1Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim1Objects2[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDbala1Objects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDbala1Objects2[i].addPolarForce((( gdjs.Cena2Code.GDinim1Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim1Objects2[0].getAngle()), 600, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "balas_timer");
}}
}

}


}; //End of gdjs.Cena2Code.eventsList0x764ef4
gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil3Objects2Objects = Hashtable.newFrom({"missil3": gdjs.Cena2Code.GDmissil3Objects2});gdjs.Cena2Code.eventsList0x71f2ac = function(runtimeScene) {

}; //End of gdjs.Cena2Code.eventsList0x71f2ac
gdjs.Cena2Code.eventsList0x76580c = function(runtimeScene) {

{

gdjs.Cena2Code.GDinim3Objects1.createFrom(runtimeScene.getObjects("inim3"));

for(gdjs.Cena2Code.forEachIndex2 = 0;gdjs.Cena2Code.forEachIndex2 < gdjs.Cena2Code.GDinim3Objects1.length;++gdjs.Cena2Code.forEachIndex2) {
gdjs.Cena2Code.GDmissil3Objects2.length = 0;

gdjs.Cena2Code.GDinim3Objects2.length = 0;


gdjs.Cena2Code.forEachTemporary2 = gdjs.Cena2Code.GDinim3Objects1[gdjs.Cena2Code.forEachIndex2];
gdjs.Cena2Code.GDinim3Objects2.push(gdjs.Cena2Code.forEachTemporary2);
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil3Objects2Objects, (( gdjs.Cena2Code.GDinim3Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim3Objects2[0].getPointX("mira_inim3")), (( gdjs.Cena2Code.GDinim3Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim3Objects2[0].getPointY("mira_inim3")), "");
}{for(var i = 0, len = gdjs.Cena2Code.GDmissil3Objects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDmissil3Objects2[i].setZOrder(90);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDmissil3Objects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDmissil3Objects2[i].setAngle((( gdjs.Cena2Code.GDinim3Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim3Objects2[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDmissil3Objects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDmissil3Objects2[i].addPolarForce((( gdjs.Cena2Code.GDinim3Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim3Objects2[0].getAngle()), 250, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "balas_timer2");
}}
}

}


}; //End of gdjs.Cena2Code.eventsList0x76580c
gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbala1Objects2Objects = Hashtable.newFrom({"bala1": gdjs.Cena2Code.GDbala1Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDchamaObjects2Objects = Hashtable.newFrom({"chama": gdjs.Cena2Code.GDchamaObjects2});gdjs.Cena2Code.eventsList0x765f14 = function(runtimeScene) {

}; //End of gdjs.Cena2Code.eventsList0x765f14
gdjs.Cena2Code.eventsList0x765dd4 = function(runtimeScene) {

{

gdjs.Cena2Code.GDinim4Objects1.createFrom(runtimeScene.getObjects("inim4"));

for(gdjs.Cena2Code.forEachIndex2 = 0;gdjs.Cena2Code.forEachIndex2 < gdjs.Cena2Code.GDinim4Objects1.length;++gdjs.Cena2Code.forEachIndex2) {
gdjs.Cena2Code.GDbala1Objects2.length = 0;

gdjs.Cena2Code.GDchamaObjects2.length = 0;

gdjs.Cena2Code.GDinim4Objects2.length = 0;


gdjs.Cena2Code.forEachTemporary2 = gdjs.Cena2Code.GDinim4Objects1[gdjs.Cena2Code.forEachIndex2];
gdjs.Cena2Code.GDinim4Objects2.push(gdjs.Cena2Code.forEachTemporary2);
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbala1Objects2Objects, (( gdjs.Cena2Code.GDinim4Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim4Objects2[0].getPointX("mira_inim4")), (( gdjs.Cena2Code.GDinim4Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim4Objects2[0].getPointY("mira_inim4")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDchamaObjects2Objects, (( gdjs.Cena2Code.GDinim4Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim4Objects2[0].getPointX("mira_inim4")), (( gdjs.Cena2Code.GDinim4Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim4Objects2[0].getPointY("mira_inim4")), "");
}{for(var i = 0, len = gdjs.Cena2Code.GDbala1Objects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDbala1Objects2[i].setZOrder(90);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDchamaObjects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDchamaObjects2[i].setZOrder(90);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDbala1Objects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDbala1Objects2[i].setAngle((( gdjs.Cena2Code.GDinim4Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim4Objects2[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDchamaObjects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDchamaObjects2[i].setAngle((( gdjs.Cena2Code.GDinim4Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim4Objects2[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDbala1Objects2.length ;i < len;++i) {
    gdjs.Cena2Code.GDbala1Objects2[i].addPolarForce((( gdjs.Cena2Code.GDinim4Objects2.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim4Objects2[0].getAngle()), 600, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "balas_timer3");
}}
}

}


}; //End of gdjs.Cena2Code.eventsList0x765dd4
gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbala1Objects2Objects = Hashtable.newFrom({"bala1": gdjs.Cena2Code.GDbala1Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects = Hashtable.newFrom({"canhao3": gdjs.Cena2Code.GDcanhao3Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil3Objects2Objects = Hashtable.newFrom({"missil3": gdjs.Cena2Code.GDmissil3Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects = Hashtable.newFrom({"canhao3": gdjs.Cena2Code.GDcanhao3Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim2Objects2Objects = Hashtable.newFrom({"inim2": gdjs.Cena2Code.GDinim2Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects = Hashtable.newFrom({"canhao3": gdjs.Cena2Code.GDcanhao3Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim3Objects2Objects = Hashtable.newFrom({"inim3": gdjs.Cena2Code.GDinim3Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects = Hashtable.newFrom({"canhao3": gdjs.Cena2Code.GDcanhao3Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects = Hashtable.newFrom({"canhao3": gdjs.Cena2Code.GDcanhao3Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDdangerObjects2Objects = Hashtable.newFrom({"danger": gdjs.Cena2Code.GDdangerObjects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects = Hashtable.newFrom({"canhao3": gdjs.Cena2Code.GDcanhao3Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim1Objects2Objects = Hashtable.newFrom({"inim1": gdjs.Cena2Code.GDinim1Objects2});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects = Hashtable.newFrom({"explosao": gdjs.Cena2Code.GDexplosaoObjects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects = Hashtable.newFrom({"explosao": gdjs.Cena2Code.GDexplosaoObjects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbalinhaObjects1Objects = Hashtable.newFrom({"balinha": gdjs.Cena2Code.GDbalinhaObjects1});gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim1Objects1Objects = Hashtable.newFrom({"inim1": gdjs.Cena2Code.GDinim1Objects1});gdjs.Cena2Code.eventsList0x767424 = function(runtimeScene) {

{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "go_delay2");
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game_over", false);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "go_delay2");
}}

}


}; //End of gdjs.Cena2Code.eventsList0x767424
gdjs.Cena2Code.eventsList0x7678d4 = function(runtimeScene) {

{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "go_delay3");
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Transicao", false);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "go_delay3");
}}

}


}; //End of gdjs.Cena2Code.eventsList0x7678d4
gdjs.Cena2Code.eventsList0x5b6e18 = function(runtimeScene) {

{



}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
gdjs.Cena2Code.GDlevel_95nObjects1.createFrom(runtimeScene.getObjects("level_n"));
gdjs.Cena2Code.GDn_95inimigosObjects1.createFrom(runtimeScene.getObjects("n_inimigos"));
gdjs.Cena2Code.GDn_95inimigos2Objects1.createFrom(runtimeScene.getObjects("n_inimigos2"));
gdjs.Cena2Code.GDscoreObjects1.createFrom(runtimeScene.getObjects("score"));
gdjs.Cena2Code.GDtempoObjects1.createFrom(runtimeScene.getObjects("tempo"));
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "disparo");
}{gdjs.evtTools.sound.playSound(runtimeScene, "som\\rw_walk.mp3", false, 90, 1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "som\\tank1.wav", true, 60, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(10);
}{for(var i = 0, len = gdjs.Cena2Code.GDn_95inimigosObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDn_95inimigosObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(3);
}{for(var i = 0, len = gdjs.Cena2Code.GDn_95inimigos2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDn_95inimigos2Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDscoreObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDscoreObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(240);
}{for(var i = 0, len = gdjs.Cena2Code.GDtempoObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDtempoObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDlevel_95nObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDlevel_95nObjects1[i].setString("02");
}
}}

}


{



}


{


{
gdjs.Cena2Code.GDcanhao3Objects1.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDtankObjects1.createFrom(runtimeScene.getObjects("tank"));
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Cena2Code.GDcanhao3Objects1.length !== 0 ? gdjs.Cena2Code.GDcanhao3Objects1[0] : null), true, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Cena2Code.GDtankObjects1.length !== 0 ? gdjs.Cena2Code.GDtankObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.Cena2Code.GDcanhao3Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDcanhao3Objects1[i].rotateTowardPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), 70, runtimeScene);
}
}}

}


{



}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
{gdjs.Cena2Code.conditionTrue_1 = gdjs.Cena2Code.condition0IsTrue_0;
gdjs.Cena2Code.condition0IsTrue_1.val = false;
gdjs.Cena2Code.condition1IsTrue_1.val = false;
{
gdjs.Cena2Code.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if( gdjs.Cena2Code.condition0IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
}
}
{
gdjs.Cena2Code.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "m");
if( gdjs.Cena2Code.condition1IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Cena2Code.eventsList0x760274(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
{gdjs.Cena2Code.conditionTrue_1 = gdjs.Cena2Code.condition0IsTrue_0;
gdjs.Cena2Code.condition0IsTrue_1.val = false;
gdjs.Cena2Code.condition1IsTrue_1.val = false;
{
gdjs.Cena2Code.condition0IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if( gdjs.Cena2Code.condition0IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
}
}
{
gdjs.Cena2Code.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if( gdjs.Cena2Code.condition1IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Cena2Code.eventsList0x760c14(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "cria_inim2");
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
gdjs.Cena2Code.GDinim2Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim2Objects1Objects, gdjs.random(800), -(50), "");
}{for(var i = 0, len = gdjs.Cena2Code.GDinim2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim2Objects1[i].setZOrder(100);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "cria_inim2");
}}

}


{


{
gdjs.Cena2Code.GDcanhao3Objects1.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDinim2Objects1.createFrom(runtimeScene.getObjects("inim2"));
{for(var i = 0, len = gdjs.Cena2Code.GDinim2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim2Objects1[i].addForceTowardObject((gdjs.Cena2Code.GDcanhao3Objects1.length !== 0 ? gdjs.Cena2Code.GDcanhao3Objects1[0] : null), 50, 0);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDinim2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim2Objects1[i].rotateTowardPosition((( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointX("mira3")), (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointY("mira3")), 0, runtimeScene);
}
}}

}


{



}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "cria_inim3");
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
gdjs.Cena2Code.GDinim3Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim3Objects1Objects, gdjs.random(800), -(80), "");
}{for(var i = 0, len = gdjs.Cena2Code.GDinim3Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim3Objects1[i].setZOrder(100);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "cria_inim3");
}}

}


{


{
gdjs.Cena2Code.GDcanhao3Objects1.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDinim3Objects1.createFrom(runtimeScene.getObjects("inim3"));
{for(var i = 0, len = gdjs.Cena2Code.GDinim3Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim3Objects1[i].addForceTowardObject((gdjs.Cena2Code.GDcanhao3Objects1.length !== 0 ? gdjs.Cena2Code.GDcanhao3Objects1[0] : null), 40, 0);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDinim3Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim3Objects1[i].rotateTowardPosition((( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointX("mira3")), (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointY("mira3")), 0, runtimeScene);
}
}}

}


{



}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
gdjs.Cena2Code.GDinim4Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim4Objects1Objects, gdjs.random(1000), -(500), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim4Objects1Objects, gdjs.random(2000), -(750), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim4Objects1Objects, gdjs.random(3000), 900, "");
}{for(var i = 0, len = gdjs.Cena2Code.GDinim4Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim4Objects1[i].setZOrder(100);
}
}}

}


{


{
gdjs.Cena2Code.GDcanhao3Objects1.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDinim4Objects1.createFrom(runtimeScene.getObjects("inim4"));
{for(var i = 0, len = gdjs.Cena2Code.GDinim4Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim4Objects1[i].addForceTowardObject((gdjs.Cena2Code.GDcanhao3Objects1.length !== 0 ? gdjs.Cena2Code.GDcanhao3Objects1[0] : null), 50, 0);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDinim4Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim4Objects1[i].rotateTowardPosition((( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointX("mira3")), (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointY("mira3")), 0, runtimeScene);
}
}}

}


{



}


{

gdjs.Cena2Code.GDinim1Objects1.createFrom(runtimeScene.getObjects("inim1"));
gdjs.Cena2Code.GDmissil2Objects1.createFrom(runtimeScene.getObjects("missil2"));

gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil2Objects1Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Cena2Code.GDinim1Objects1 */
/* Reuse gdjs.Cena2Code.GDmissil2Objects1 */
gdjs.Cena2Code.GDn_95inimigosObjects1.createFrom(runtimeScene.getObjects("n_inimigos"));
gdjs.Cena2Code.GDscoreObjects1.createFrom(runtimeScene.getObjects("score"));
gdjs.Cena2Code.GDexplosaoObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects, (( gdjs.Cena2Code.GDinim1Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim1Objects1[0].getPointX("")), (( gdjs.Cena2Code.GDinim1Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim1Objects1[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "som\\Tiro2.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Cena2Code.GDexplosaoObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDexplosaoObjects1[i].setZOrder(50);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{for(var i = 0, len = gdjs.Cena2Code.GDn_95inimigosObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDn_95inimigosObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(20);
}{for(var i = 0, len = gdjs.Cena2Code.GDscoreObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDscoreObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDinim1Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDmissil2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDmissil2Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.Cena2Code.GDinim4Objects1.createFrom(runtimeScene.getObjects("inim4"));
gdjs.Cena2Code.GDmissil2Objects1.createFrom(runtimeScene.getObjects("missil2"));

gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil2Objects1Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim4Objects1Objects, false, runtimeScene, false);
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Cena2Code.GDinim4Objects1 */
/* Reuse gdjs.Cena2Code.GDmissil2Objects1 */
gdjs.Cena2Code.GDn_95inimigos2Objects1.createFrom(runtimeScene.getObjects("n_inimigos2"));
gdjs.Cena2Code.GDscoreObjects1.createFrom(runtimeScene.getObjects("score"));
gdjs.Cena2Code.GDexplosaoObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects, (( gdjs.Cena2Code.GDinim4Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim4Objects1[0].getPointX("")), (( gdjs.Cena2Code.GDinim4Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim4Objects1[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "som\\Tiro2.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Cena2Code.GDexplosaoObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDexplosaoObjects1[i].setZOrder(50);
}
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub(1);
}{for(var i = 0, len = gdjs.Cena2Code.GDn_95inimigos2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDn_95inimigos2Objects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(40);
}{for(var i = 0, len = gdjs.Cena2Code.GDscoreObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDscoreObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDinim4Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim4Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDmissil2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDmissil2Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.Cena2Code.GDexplosaoObjects1.createFrom(runtimeScene.getObjects("explosao"));

gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Cena2Code.GDexplosaoObjects1.length;i<l;++i) {
    if ( gdjs.Cena2Code.GDexplosaoObjects1[i].hasAnimationEnded() ) {
        gdjs.Cena2Code.condition0IsTrue_0.val = true;
        gdjs.Cena2Code.GDexplosaoObjects1[k] = gdjs.Cena2Code.GDexplosaoObjects1[i];
        ++k;
    }
}
gdjs.Cena2Code.GDexplosaoObjects1.length = k;}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Cena2Code.GDexplosaoObjects1 */
{for(var i = 0, len = gdjs.Cena2Code.GDexplosaoObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDexplosaoObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.Cena2Code.GDchamaObjects1.createFrom(runtimeScene.getObjects("chama"));

gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Cena2Code.GDchamaObjects1.length;i<l;++i) {
    if ( gdjs.Cena2Code.GDchamaObjects1[i].hasAnimationEnded() ) {
        gdjs.Cena2Code.condition0IsTrue_0.val = true;
        gdjs.Cena2Code.GDchamaObjects1[k] = gdjs.Cena2Code.GDchamaObjects1[i];
        ++k;
    }
}
gdjs.Cena2Code.GDchamaObjects1.length = k;}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Cena2Code.GDchamaObjects1 */
{for(var i = 0, len = gdjs.Cena2Code.GDchamaObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDchamaObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.Cena2Code.GDbalinhaObjects1.length = 0;

gdjs.Cena2Code.GDinim2Objects1.length = 0;

gdjs.Cena2Code.GDinim3Objects1.length = 0;


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
{gdjs.Cena2Code.conditionTrue_1 = gdjs.Cena2Code.condition0IsTrue_0;
gdjs.Cena2Code.GDbalinhaObjects1_1final.length = 0;gdjs.Cena2Code.GDinim2Objects1_1final.length = 0;gdjs.Cena2Code.GDinim3Objects1_1final.length = 0;gdjs.Cena2Code.condition0IsTrue_1.val = false;
gdjs.Cena2Code.condition1IsTrue_1.val = false;
{
gdjs.Cena2Code.GDbalinhaObjects2.createFrom(runtimeScene.getObjects("balinha"));
gdjs.Cena2Code.GDinim2Objects2.createFrom(runtimeScene.getObjects("inim2"));
gdjs.Cena2Code.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbalinhaObjects2Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim2Objects2Objects, false, runtimeScene, false);
if( gdjs.Cena2Code.condition0IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Cena2Code.GDbalinhaObjects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDbalinhaObjects1_1final.indexOf(gdjs.Cena2Code.GDbalinhaObjects2[j]) === -1 )
            gdjs.Cena2Code.GDbalinhaObjects1_1final.push(gdjs.Cena2Code.GDbalinhaObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.Cena2Code.GDinim2Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDinim2Objects1_1final.indexOf(gdjs.Cena2Code.GDinim2Objects2[j]) === -1 )
            gdjs.Cena2Code.GDinim2Objects1_1final.push(gdjs.Cena2Code.GDinim2Objects2[j]);
    }
}
}
{
gdjs.Cena2Code.GDbalinhaObjects2.createFrom(runtimeScene.getObjects("balinha"));
gdjs.Cena2Code.GDinim3Objects2.createFrom(runtimeScene.getObjects("inim3"));
gdjs.Cena2Code.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbalinhaObjects2Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim3Objects2Objects, false, runtimeScene, false);
if( gdjs.Cena2Code.condition1IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Cena2Code.GDbalinhaObjects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDbalinhaObjects1_1final.indexOf(gdjs.Cena2Code.GDbalinhaObjects2[j]) === -1 )
            gdjs.Cena2Code.GDbalinhaObjects1_1final.push(gdjs.Cena2Code.GDbalinhaObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.Cena2Code.GDinim3Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDinim3Objects1_1final.indexOf(gdjs.Cena2Code.GDinim3Objects2[j]) === -1 )
            gdjs.Cena2Code.GDinim3Objects1_1final.push(gdjs.Cena2Code.GDinim3Objects2[j]);
    }
}
}
{
gdjs.Cena2Code.GDbalinhaObjects1.createFrom(gdjs.Cena2Code.GDbalinhaObjects1_1final);
gdjs.Cena2Code.GDinim2Objects1.createFrom(gdjs.Cena2Code.GDinim2Objects1_1final);
gdjs.Cena2Code.GDinim3Objects1.createFrom(gdjs.Cena2Code.GDinim3Objects1_1final);
}
}
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Cena2Code.GDbalinhaObjects1 */
/* Reuse gdjs.Cena2Code.GDinim2Objects1 */
/* Reuse gdjs.Cena2Code.GDinim3Objects1 */
gdjs.Cena2Code.GDscoreObjects1.createFrom(runtimeScene.getObjects("score"));
gdjs.Cena2Code.GDexplosaoObjects1.length = 0;

gdjs.Cena2Code.GDsangueObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDsangueObjects1Objects, (( gdjs.Cena2Code.GDinim2Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim2Objects1[0].getPointX("")), (( gdjs.Cena2Code.GDinim2Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim2Objects1[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects, (( gdjs.Cena2Code.GDinim2Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim2Objects1[0].getPointX("")), (( gdjs.Cena2Code.GDinim2Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDinim2Objects1[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "som\\Tiro2.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Cena2Code.GDexplosaoObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDexplosaoObjects1[i].setZOrder(50);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDsangueObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDsangueObjects1[i].setZOrder(50);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(2);
}{for(var i = 0, len = gdjs.Cena2Code.GDscoreObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDscoreObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.Cena2Code.GDinim2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDinim3Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim3Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDbalinhaObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDbalinhaObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.Cena2Code.GDbalinhaObjects1.createFrom(runtimeScene.getObjects("balinha"));
gdjs.Cena2Code.GDmissil3Objects1.createFrom(runtimeScene.getObjects("missil3"));

gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbalinhaObjects1Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil3Objects1Objects, false, runtimeScene, false);
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Cena2Code.GDmissil3Objects1 */
gdjs.Cena2Code.GDexplosaoObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects, (( gdjs.Cena2Code.GDmissil3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDmissil3Objects1[0].getPointX("")), (( gdjs.Cena2Code.GDmissil3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDmissil3Objects1[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "som\\Tiro2.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Cena2Code.GDexplosaoObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDexplosaoObjects1[i].setZOrder(50);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDmissil3Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDmissil3Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.Cena2Code.GDsangueObjects1.createFrom(runtimeScene.getObjects("sangue"));

gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Cena2Code.GDsangueObjects1.length;i<l;++i) {
    if ( gdjs.Cena2Code.GDsangueObjects1[i].hasAnimationEnded() ) {
        gdjs.Cena2Code.condition0IsTrue_0.val = true;
        gdjs.Cena2Code.GDsangueObjects1[k] = gdjs.Cena2Code.GDsangueObjects1[i];
        ++k;
    }
}
gdjs.Cena2Code.GDsangueObjects1.length = k;}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Cena2Code.GDsangueObjects1 */
{for(var i = 0, len = gdjs.Cena2Code.GDsangueObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDsangueObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2, "balas_timer");
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Cena2Code.eventsList0x764ef4(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 10, "balas_timer2");
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Cena2Code.eventsList0x76580c(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "balas_timer3");
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Cena2Code.eventsList0x765dd4(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.Cena2Code.GDbala1Objects1.length = 0;

gdjs.Cena2Code.GDcanhao3Objects1.length = 0;

gdjs.Cena2Code.GDdangerObjects1.length = 0;

gdjs.Cena2Code.GDinim1Objects1.length = 0;

gdjs.Cena2Code.GDinim2Objects1.length = 0;

gdjs.Cena2Code.GDinim3Objects1.length = 0;

gdjs.Cena2Code.GDmissil3Objects1.length = 0;


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
{gdjs.Cena2Code.conditionTrue_1 = gdjs.Cena2Code.condition0IsTrue_0;
gdjs.Cena2Code.GDbala1Objects1_1final.length = 0;gdjs.Cena2Code.GDcanhao3Objects1_1final.length = 0;gdjs.Cena2Code.GDdangerObjects1_1final.length = 0;gdjs.Cena2Code.GDinim1Objects1_1final.length = 0;gdjs.Cena2Code.GDinim2Objects1_1final.length = 0;gdjs.Cena2Code.GDinim3Objects1_1final.length = 0;gdjs.Cena2Code.GDmissil3Objects1_1final.length = 0;gdjs.Cena2Code.condition0IsTrue_1.val = false;
gdjs.Cena2Code.condition1IsTrue_1.val = false;
gdjs.Cena2Code.condition2IsTrue_1.val = false;
gdjs.Cena2Code.condition3IsTrue_1.val = false;
gdjs.Cena2Code.condition4IsTrue_1.val = false;
gdjs.Cena2Code.condition5IsTrue_1.val = false;
{
gdjs.Cena2Code.GDbala1Objects2.createFrom(runtimeScene.getObjects("bala1"));
gdjs.Cena2Code.GDcanhao3Objects2.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbala1Objects2Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects, false, runtimeScene, false);
if( gdjs.Cena2Code.condition0IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Cena2Code.GDbala1Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDbala1Objects1_1final.indexOf(gdjs.Cena2Code.GDbala1Objects2[j]) === -1 )
            gdjs.Cena2Code.GDbala1Objects1_1final.push(gdjs.Cena2Code.GDbala1Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.Cena2Code.GDcanhao3Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDcanhao3Objects1_1final.indexOf(gdjs.Cena2Code.GDcanhao3Objects2[j]) === -1 )
            gdjs.Cena2Code.GDcanhao3Objects1_1final.push(gdjs.Cena2Code.GDcanhao3Objects2[j]);
    }
}
}
{
gdjs.Cena2Code.GDcanhao3Objects2.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDmissil3Objects2.createFrom(runtimeScene.getObjects("missil3"));
gdjs.Cena2Code.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDmissil3Objects2Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects, false, runtimeScene, false);
if( gdjs.Cena2Code.condition1IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Cena2Code.GDcanhao3Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDcanhao3Objects1_1final.indexOf(gdjs.Cena2Code.GDcanhao3Objects2[j]) === -1 )
            gdjs.Cena2Code.GDcanhao3Objects1_1final.push(gdjs.Cena2Code.GDcanhao3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.Cena2Code.GDmissil3Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDmissil3Objects1_1final.indexOf(gdjs.Cena2Code.GDmissil3Objects2[j]) === -1 )
            gdjs.Cena2Code.GDmissil3Objects1_1final.push(gdjs.Cena2Code.GDmissil3Objects2[j]);
    }
}
}
{
gdjs.Cena2Code.GDcanhao3Objects2.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDinim2Objects2.createFrom(runtimeScene.getObjects("inim2"));
gdjs.Cena2Code.condition2IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim2Objects2Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects, false, runtimeScene, true);
if( gdjs.Cena2Code.condition2IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Cena2Code.GDcanhao3Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDcanhao3Objects1_1final.indexOf(gdjs.Cena2Code.GDcanhao3Objects2[j]) === -1 )
            gdjs.Cena2Code.GDcanhao3Objects1_1final.push(gdjs.Cena2Code.GDcanhao3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.Cena2Code.GDinim2Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDinim2Objects1_1final.indexOf(gdjs.Cena2Code.GDinim2Objects2[j]) === -1 )
            gdjs.Cena2Code.GDinim2Objects1_1final.push(gdjs.Cena2Code.GDinim2Objects2[j]);
    }
}
}
{
gdjs.Cena2Code.GDcanhao3Objects2.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDinim3Objects2.createFrom(runtimeScene.getObjects("inim3"));
gdjs.Cena2Code.condition3IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim3Objects2Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects, false, runtimeScene, true);
if( gdjs.Cena2Code.condition3IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Cena2Code.GDcanhao3Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDcanhao3Objects1_1final.indexOf(gdjs.Cena2Code.GDcanhao3Objects2[j]) === -1 )
            gdjs.Cena2Code.GDcanhao3Objects1_1final.push(gdjs.Cena2Code.GDcanhao3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.Cena2Code.GDinim3Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDinim3Objects1_1final.indexOf(gdjs.Cena2Code.GDinim3Objects2[j]) === -1 )
            gdjs.Cena2Code.GDinim3Objects1_1final.push(gdjs.Cena2Code.GDinim3Objects2[j]);
    }
}
}
{
gdjs.Cena2Code.GDcanhao3Objects2.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDdangerObjects2.createFrom(runtimeScene.getObjects("danger"));
gdjs.Cena2Code.condition4IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDdangerObjects2Objects, false, runtimeScene, true);
if( gdjs.Cena2Code.condition4IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Cena2Code.GDcanhao3Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDcanhao3Objects1_1final.indexOf(gdjs.Cena2Code.GDcanhao3Objects2[j]) === -1 )
            gdjs.Cena2Code.GDcanhao3Objects1_1final.push(gdjs.Cena2Code.GDcanhao3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.Cena2Code.GDdangerObjects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDdangerObjects1_1final.indexOf(gdjs.Cena2Code.GDdangerObjects2[j]) === -1 )
            gdjs.Cena2Code.GDdangerObjects1_1final.push(gdjs.Cena2Code.GDdangerObjects2[j]);
    }
}
}
{
gdjs.Cena2Code.GDcanhao3Objects2.createFrom(runtimeScene.getObjects("canhao3"));
gdjs.Cena2Code.GDinim1Objects2.createFrom(runtimeScene.getObjects("inim1"));
gdjs.Cena2Code.condition5IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDcanhao3Objects2Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim1Objects2Objects, false, runtimeScene, true);
if( gdjs.Cena2Code.condition5IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Cena2Code.GDcanhao3Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDcanhao3Objects1_1final.indexOf(gdjs.Cena2Code.GDcanhao3Objects2[j]) === -1 )
            gdjs.Cena2Code.GDcanhao3Objects1_1final.push(gdjs.Cena2Code.GDcanhao3Objects2[j]);
    }
    for(var j = 0, jLen = gdjs.Cena2Code.GDinim1Objects2.length;j<jLen;++j) {
        if ( gdjs.Cena2Code.GDinim1Objects1_1final.indexOf(gdjs.Cena2Code.GDinim1Objects2[j]) === -1 )
            gdjs.Cena2Code.GDinim1Objects1_1final.push(gdjs.Cena2Code.GDinim1Objects2[j]);
    }
}
}
{
gdjs.Cena2Code.GDbala1Objects1.createFrom(gdjs.Cena2Code.GDbala1Objects1_1final);
gdjs.Cena2Code.GDcanhao3Objects1.createFrom(gdjs.Cena2Code.GDcanhao3Objects1_1final);
gdjs.Cena2Code.GDdangerObjects1.createFrom(gdjs.Cena2Code.GDdangerObjects1_1final);
gdjs.Cena2Code.GDinim1Objects1.createFrom(gdjs.Cena2Code.GDinim1Objects1_1final);
gdjs.Cena2Code.GDinim2Objects1.createFrom(gdjs.Cena2Code.GDinim2Objects1_1final);
gdjs.Cena2Code.GDinim3Objects1.createFrom(gdjs.Cena2Code.GDinim3Objects1_1final);
gdjs.Cena2Code.GDmissil3Objects1.createFrom(gdjs.Cena2Code.GDmissil3Objects1_1final);
}
}
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Cena2Code.GDbala1Objects1 */
/* Reuse gdjs.Cena2Code.GDcanhao3Objects1 */
/* Reuse gdjs.Cena2Code.GDinim2Objects1 */
/* Reuse gdjs.Cena2Code.GDinim3Objects1 */
/* Reuse gdjs.Cena2Code.GDmissil3Objects1 */
gdjs.Cena2Code.GDtankObjects1.createFrom(runtimeScene.getObjects("tank"));
gdjs.Cena2Code.GDexplosaoObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects, (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointX("")), (( gdjs.Cena2Code.GDcanhao3Objects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDcanhao3Objects1[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDexplosaoObjects1Objects, (( gdjs.Cena2Code.GDtankObjects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDtankObjects1[0].getPointX("")), (( gdjs.Cena2Code.GDtankObjects1.length === 0 ) ? 0 :gdjs.Cena2Code.GDtankObjects1[0].getPointY("")), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "som\\Tiro2.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Cena2Code.GDexplosaoObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDexplosaoObjects1[i].setZOrder(50);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDtankObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDtankObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDcanhao3Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDcanhao3Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDinim2Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDinim3Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDinim3Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDmissil3Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDmissil3Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Cena2Code.GDbala1Objects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDbala1Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.Cena2Code.GDbalinhaObjects1.createFrom(runtimeScene.getObjects("balinha"));
gdjs.Cena2Code.GDinim1Objects1.createFrom(runtimeScene.getObjects("inim1"));

gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDbalinhaObjects1Objects, gdjs.Cena2Code.mapOfGDgdjs_46Cena2Code_46GDinim1Objects1Objects, false, runtimeScene, false);
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Cena2Code.GDbalinhaObjects1 */
{for(var i = 0, len = gdjs.Cena2Code.GDbalinhaObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDbalinhaObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
{gdjs.Cena2Code.conditionTrue_1 = gdjs.Cena2Code.condition0IsTrue_0;
gdjs.Cena2Code.condition0IsTrue_1.val = false;
gdjs.Cena2Code.condition1IsTrue_1.val = false;
{
gdjs.Cena2Code.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 0;
if( gdjs.Cena2Code.condition0IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
}
}
{
gdjs.Cena2Code.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 1;
if( gdjs.Cena2Code.condition1IsTrue_1.val ) {
    gdjs.Cena2Code.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Cena2Code.eventsList0x767424(runtimeScene);} //End of subevents
}

}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
{gdjs.Cena2Code.conditionTrue_1 = gdjs.Cena2Code.condition0IsTrue_0;
gdjs.Cena2Code.condition0IsTrue_1.val = false;
gdjs.Cena2Code.condition1IsTrue_1.val = false;
{
gdjs.Cena2Code.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 0;
}if ( gdjs.Cena2Code.condition0IsTrue_1.val ) {
{
gdjs.Cena2Code.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 0;
}}
gdjs.Cena2Code.conditionTrue_1.val = true && gdjs.Cena2Code.condition0IsTrue_1.val && gdjs.Cena2Code.condition1IsTrue_1.val;
}
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Cena2Code.eventsList0x7678d4(runtimeScene);} //End of subevents
}

}


{


gdjs.Cena2Code.condition0IsTrue_0.val = false;
{
gdjs.Cena2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "tempo_jogo");
}if (gdjs.Cena2Code.condition0IsTrue_0.val) {
gdjs.Cena2Code.GDtempoObjects1.createFrom(runtimeScene.getObjects("tempo"));
{runtimeScene.getGame().getVariables().getFromIndex(3).sub(1);
}{for(var i = 0, len = gdjs.Cena2Code.GDtempoObjects1.length ;i < len;++i) {
    gdjs.Cena2Code.GDtempoObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "tempo_jogo");
}}

}


}; //End of gdjs.Cena2Code.eventsList0x5b6e18


gdjs.Cena2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Cena2Code.GDterrenoObjects1.length = 0;
gdjs.Cena2Code.GDterrenoObjects2.length = 0;
gdjs.Cena2Code.GDtankObjects1.length = 0;
gdjs.Cena2Code.GDtankObjects2.length = 0;
gdjs.Cena2Code.GDcanhao3Objects1.length = 0;
gdjs.Cena2Code.GDcanhao3Objects2.length = 0;
gdjs.Cena2Code.GDmissil2Objects1.length = 0;
gdjs.Cena2Code.GDmissil2Objects2.length = 0;
gdjs.Cena2Code.GDbala1Objects1.length = 0;
gdjs.Cena2Code.GDbala1Objects2.length = 0;
gdjs.Cena2Code.GDbalinhaObjects1.length = 0;
gdjs.Cena2Code.GDbalinhaObjects2.length = 0;
gdjs.Cena2Code.GDchamaObjects1.length = 0;
gdjs.Cena2Code.GDchamaObjects2.length = 0;
gdjs.Cena2Code.GDexplosaoObjects1.length = 0;
gdjs.Cena2Code.GDexplosaoObjects2.length = 0;
gdjs.Cena2Code.GDsangueObjects1.length = 0;
gdjs.Cena2Code.GDsangueObjects2.length = 0;
gdjs.Cena2Code.GDinim1Objects1.length = 0;
gdjs.Cena2Code.GDinim1Objects2.length = 0;
gdjs.Cena2Code.GDinim2Objects1.length = 0;
gdjs.Cena2Code.GDinim2Objects2.length = 0;
gdjs.Cena2Code.GDdangerObjects1.length = 0;
gdjs.Cena2Code.GDdangerObjects2.length = 0;
gdjs.Cena2Code.GDlevelObjects1.length = 0;
gdjs.Cena2Code.GDlevelObjects2.length = 0;
gdjs.Cena2Code.GDlevel_95nObjects1.length = 0;
gdjs.Cena2Code.GDlevel_95nObjects2.length = 0;
gdjs.Cena2Code.GDscoreObjects1.length = 0;
gdjs.Cena2Code.GDscoreObjects2.length = 0;
gdjs.Cena2Code.GDn_95inimigosObjects1.length = 0;
gdjs.Cena2Code.GDn_95inimigosObjects2.length = 0;
gdjs.Cena2Code.GDtempoObjects1.length = 0;
gdjs.Cena2Code.GDtempoObjects2.length = 0;
gdjs.Cena2Code.GDinim11Objects1.length = 0;
gdjs.Cena2Code.GDinim11Objects2.length = 0;
gdjs.Cena2Code.GDmedalObjects1.length = 0;
gdjs.Cena2Code.GDmedalObjects2.length = 0;
gdjs.Cena2Code.GDampulhetaObjects1.length = 0;
gdjs.Cena2Code.GDampulhetaObjects2.length = 0;
gdjs.Cena2Code.GDteclasObjects1.length = 0;
gdjs.Cena2Code.GDteclasObjects2.length = 0;
gdjs.Cena2Code.GDpointerObjects1.length = 0;
gdjs.Cena2Code.GDpointerObjects2.length = 0;
gdjs.Cena2Code.GDleftObjects1.length = 0;
gdjs.Cena2Code.GDleftObjects2.length = 0;
gdjs.Cena2Code.GDrightObjects1.length = 0;
gdjs.Cena2Code.GDrightObjects2.length = 0;
gdjs.Cena2Code.GDinfo1Objects1.length = 0;
gdjs.Cena2Code.GDinfo1Objects2.length = 0;
gdjs.Cena2Code.GDinfo2Objects1.length = 0;
gdjs.Cena2Code.GDinfo2Objects2.length = 0;
gdjs.Cena2Code.GDinfo3Objects1.length = 0;
gdjs.Cena2Code.GDinfo3Objects2.length = 0;
gdjs.Cena2Code.GDinfo4Objects1.length = 0;
gdjs.Cena2Code.GDinfo4Objects2.length = 0;
gdjs.Cena2Code.GDinim3Objects1.length = 0;
gdjs.Cena2Code.GDinim3Objects2.length = 0;
gdjs.Cena2Code.GDmissil3Objects1.length = 0;
gdjs.Cena2Code.GDmissil3Objects2.length = 0;
gdjs.Cena2Code.GDinim4Objects1.length = 0;
gdjs.Cena2Code.GDinim4Objects2.length = 0;
gdjs.Cena2Code.GDn_95inimigos2Objects1.length = 0;
gdjs.Cena2Code.GDn_95inimigos2Objects2.length = 0;
gdjs.Cena2Code.GDinim41Objects1.length = 0;
gdjs.Cena2Code.GDinim41Objects2.length = 0;

gdjs.Cena2Code.eventsList0x5b6e18(runtimeScene);
return;

}

gdjs['Cena2Code'] = gdjs.Cena2Code;
